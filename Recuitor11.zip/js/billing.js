function billing(evt, cityName) {
    // Declare all variables
    var i, tabcontent, tablinks;
  
    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("billing-tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
  
    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("billing-tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
  
    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
  }
 document.getElementById("billing").click();


  // show and hide view

  $('.view-action').on('click',function(){
    $('.orders').css({'display':'none'});
    $('.view-order').css({'display':'block'});
  });
  $('.back-btn').on('click',function(){
    $('.orders').css({'display':'block'});
    $('.view-order').css({'display':'none'})
  });

 

 // Show and hide invoice
  $('.invoice-action ').on('click',function(){
    $('.orders').css({'display':'none'});
    $('.Invoice').css({'display':'block'});
  });
  $('.back-btn').on('click',function(){
    $('.orders').css({'display':'block'});
    $('.Invoice').css({'display':'none'})
  });

